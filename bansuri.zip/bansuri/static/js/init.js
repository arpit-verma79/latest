document.documentElement.className+=' js';
